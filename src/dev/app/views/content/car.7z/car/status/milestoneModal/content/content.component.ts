﻿import {Component} from 'angular2/core';

@Component({
    selector: 'content',
    template: 'milestone ---  Content !!'
})

export class ContentComponent {

}