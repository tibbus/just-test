﻿import {Component} from 'angular2/core';

@Component({
    selector: 'content',
    template: 'some Content !!'
})

export class ContentComponent {
    public title: string = "Hello there !";
}